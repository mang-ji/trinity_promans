package team3.promans.beans;

import lombok.Data;

@Data
public class CpMemberBean {
	private String cpcode;
	private String cpname;
	private String ceo;
	private String cplocate;
	private String userid;
	private String acode;
	private String uname;
	private String uphone;
	private String tecode;
	private String tename;
	private String mail;
	private String wcode;
	private String utype;
}
