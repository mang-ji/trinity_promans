package team3.promans.beans;

import lombok.Data;

@Data
public class CloudBean {
	private String cpcode;
	private String prcode;
	private String pscode;
	private String sccode;
	private String fcode;
	private String fname;
	private String filepath;
	private String ftitle;
	private String fdate;
	private String fwriter;
	private String fopen;
	private String userid;
}
