package team3.promans.beans;

import lombok.Data;

@Data
public class ScheduleDetailBean {
	private String cpcode;
	private String userid;
	private String prcode;
	private String pscode;
	private String sccode;
	private String wcode;
	private String utype;
	private String sdcode;
	private String sdname;
	private String sdtitle;
	private String sddate;
	private String sddstate;
}
