package team3.promans.interfaces;

import org.springframework.stereotype.Component;

@Component
public interface SelectInterface {

}
