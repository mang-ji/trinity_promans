package team3.promans.services;

public class test {
	
	public test() {
		
	}
		
	public void test1() {
		System.out.println("테스트");
	}
	public void test3() {
		System.out.println("테스트3");
	}
	public void test2() {
		System.out.println("테스트2");
	}
	public void test4() {
		System.out.println("고쳐줘!");
	}
	public void test6() {
		System.out.println("이거얌");
	}
	public void test7() {
		System.out.println("요나얌");
	}
}
