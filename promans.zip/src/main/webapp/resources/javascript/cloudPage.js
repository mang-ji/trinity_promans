function clickBtn(){
	let popup = document.getElementById("popup");
	
	popup.style.display = "block";
}

function getFileList(data){
	
}
