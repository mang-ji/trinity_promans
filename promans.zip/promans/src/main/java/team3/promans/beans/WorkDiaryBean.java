package team3.promans.beans;

import lombok.Data;

@Data
public class WorkDiaryBean {
	private String cpcode;
	private String prcode;
	private String userid;
	private String wdcode;
	private String wdtitle;
	private String wdcontents;
	private String wddate;
}
