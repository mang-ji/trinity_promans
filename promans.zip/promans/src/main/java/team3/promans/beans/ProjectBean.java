package team3.promans.beans;

import lombok.Data;

@Data
public class ProjectBean {
	private String cpcode;
	private String userid;
	private String prcode;
	private String prname;
	private String propen;
	private String prstate;	
	private String prdate;
	private String prsdate;
	private String prldate;
	private String prcontent;
	private String prutype;

}
