package team3.promans.beans;

import java.util.List;

import lombok.Data;

@Data
public class GraphDataBean {
	
	private int stepW;
	private int stepI;
	private int stepC;
	private int scheW;
	private int scheI;
	private int scheC;
	private int sdW;
	private int sdI;
	private int sdC;
	private String prcode;
	private String pscode;

}
