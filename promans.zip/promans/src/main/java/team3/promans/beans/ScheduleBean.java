package team3.promans.beans;

import lombok.Data;

@Data
public class ScheduleBean {
	private String cpcode;
	private String prcode;
	private String pscode;
	private String sccode;
	private String scname;
	private String scstate;
	private String scstcode;
	private String userid;
	private String utype;
}
